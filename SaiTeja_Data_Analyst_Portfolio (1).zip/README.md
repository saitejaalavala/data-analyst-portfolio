
# 📊 Sai Teja Alavala – Data Analyst Portfolio

Welcome to my Data Analyst portfolio! I’m Sai Teja Alavala, a data analyst with 4+ years of experience transforming raw data into business insights using Python, SQL, AWS, Tableau, and Power BI. My portfolio includes real-world projects demonstrating ETL development, data visualization, machine learning, and dashboard creation.

---

## 🔍 Featured Projects

### 1. Customer Churn Prediction Dashboard
**Problem:** Predict customer churn and provide insights for retention strategies.  
**Tools:** Python, Pandas, Scikit-learn, SQL, Tableau  
**Summary:** Trained a logistic regression model (85% accuracy) to predict churn for a telecom company. Built a Tableau dashboard for decision-makers.  
[🔗 GitHub Repo](#) | [📊 Tableau Dashboard](#)

---

### 2. Sales Performance ETL and BI Dashboard
**Problem:** Automate sales data transformation for business intelligence.  
**Tools:** Python, Pandas, SQL, AWS S3, Power BI  
**Summary:** Built a Python ETL pipeline to process monthly sales data, stored in AWS S3, and visualized KPIs in Power BI. Improved data refresh time by 40%.  
[🔗 GitHub Repo](#) | [📊 Power BI Report](#)

---

### 3. COVID-19 Exploratory Data Analysis
**Problem:** Explore global COVID-19 trends and government responses.  
**Tools:** Python, Plotly, Pandas, Jupyter Notebook  
**Summary:** Analyzed global cases, mortality, and vaccination trends. Built interactive visualizations with Plotly.  
[🔗 GitHub Repo](#)

---

## 🧠 Skills & Tools
- **Languages:** Python, SQL, R, JavaScript  
- **Data Analysis:** Pandas, NumPy, Scikit-learn, TensorFlow  
- **Visualization:** Tableau, Power BI, Plotly, Seaborn  
- **Databases:** MySQL, PostgreSQL, Snowflake, AWS Redshift  
- **Cloud:** AWS (S3, Glue, Redshift), Azure (Data Factory)  
- **Others:** Git, Excel, Jupyter, Airflow

---

## 📫 Let's Connect
- **LinkedIn:** [linkedin.com/in/saitejaalavala](https://linkedin.com/in/saitejaalavala)
- **Email:** saiteja.alavala17@gmail.com

