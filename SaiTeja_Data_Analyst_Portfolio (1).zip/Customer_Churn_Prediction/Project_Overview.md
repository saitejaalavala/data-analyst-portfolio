
# Customer Churn Prediction

**Problem:** Predict customer churn to guide retention strategy.

**Tools Used:** Python, Pandas, Scikit-learn, SQL, Tableau

**Steps:**
- Data cleaning and preprocessing using Pandas
- Feature engineering (tenure, payment type clusters)
- Trained logistic regression model (85% accuracy)
- Built Tableau dashboard for executives

**Outcome:** Reduced churn rate by 12% in pilot region.

[🔗 Tableau Dashboard](#) | [🔗 GitHub Repo](#)
