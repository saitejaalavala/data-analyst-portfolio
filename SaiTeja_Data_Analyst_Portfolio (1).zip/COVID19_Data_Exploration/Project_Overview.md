
# COVID-19 Data Exploration

**Problem:** Understand global COVID-19 impact through data.

**Tools Used:** Python, Plotly, Pandas, Jupyter Notebook

**Steps:**
- Loaded data from public sources
- Cleaned and transformed using Pandas
- Created interactive visualizations with Plotly

**Outcome:** Identified key trends in mortality and vaccination.

[🔗 GitHub Repo](#)
