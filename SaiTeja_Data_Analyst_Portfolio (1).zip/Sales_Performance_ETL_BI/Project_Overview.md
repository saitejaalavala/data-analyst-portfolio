
# Sales Performance ETL and BI Dashboard

**Problem:** Automate sales data transformation for BI reporting.

**Tools Used:** Python, Pandas, SQL, AWS S3, Power BI

**Steps:**
- Extracted monthly sales data
- Transformed and cleaned using Pandas
- Stored in AWS S3, queried via SQL
- Visualized KPIs in Power BI

**Outcome:** Improved data refresh time by 40%.

[🔗 Power BI Report](#) | [🔗 GitHub Repo](#)
